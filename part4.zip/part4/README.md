```
cd ..
cd part4
kubectl apply -f ingress-controller
kubectl apply -f products-db
kubectl apply -f products-api
kubectl apply -f stock-api
kubectl apply -f web
```
